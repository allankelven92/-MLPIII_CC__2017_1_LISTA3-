package br.exercicios.lista.ex1.modelo;

import java.lang.Comparable;

public class Produto implements Comparable<Produto> {
    private Integer codigo;
    private String nome;
    private double valor;

    public Produto(Integer codigo, String nome, double valor) {
        this.codigo = codigo;
        this.nome = nome;
        this.valor = valor;
    }

	public Integer getCodigo() {
		return codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

    public int compareTo(Produto produto) {
        return (this.codigo).compareTo(produto.codigo);
    }

    public String toString() {
        return "[Produto] " + this.codigo + " " + this.nome + " " + this.valor;
    }
}
