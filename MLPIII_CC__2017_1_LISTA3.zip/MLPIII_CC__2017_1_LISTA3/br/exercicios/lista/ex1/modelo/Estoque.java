package br.exercicios.lista.ex1.modelo;

import java.util.Set;
import br.exercicios.lista.ex1.modelo.Produto;

public class Estoque {
    private String nome;
    private Set<Produto> produtos;

    public Estoque(String nome, Set<Produto> produtos) {
        this.nome = nome;
        this.produtos = produtos;
    }

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Set<Produto> getProdutos() {
		return produtos;
	}

    public String toString () {
        String string = ("[Estoque] " + this.nome);

        for (Produto produto : produtos) {
            string += ("\n  " + produto);
        }

        return string;
    }
}
