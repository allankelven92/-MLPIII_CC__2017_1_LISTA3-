package br.exercicios.lista.ex1.fachada;  

import java.util.HashSet;
import java.util.Map;
import java.util.HashMap;
import br.exercicios.lista.ex1.modelo.Produto;
import br.exercicios.lista.ex1.modelo.Estoque;

public class Principal {
    public static void main(String[] args) {

        Map<String, Estoque> mapaEstoques = new HashMap<>();

        mapaEstoques.put("Central", new Estoque("Estoque Central", new HashSet<>()));
        mapaEstoques.put("Setorial", new Estoque("Estoque Setorial", new HashSet<>()));

        mapaEstoques.get("Central").getProdutos().add(new Produto(156, "Teclado USB", 25.00));
        mapaEstoques.get("Central").getProdutos().add(new Produto(196, "Mouse USB", 15.00));
        mapaEstoques.get("Central").getProdutos().add(new Produto(185, "Roteador Wireless", 90.00));
        mapaEstoques.get("Central").getProdutos().add(new Produto(156, "Mouse sem fio", 60.00));

        mapaEstoques.get("Setorial").getProdutos().add(new Produto(102, "Mouse USB", 15.00));
        mapaEstoques.get("Setorial").getProdutos().add(new Produto(322, "Bluetooth USB", 20.00));
        mapaEstoques.get("Setorial").getProdutos().add(new Produto(932, "Memoria RAM DDR3 4Gb", 169.00));

        System.out.println(mapaEstoques.get("Central"));
        System.out.println("\n" + mapaEstoques.get("Setorial"));

    }
}
