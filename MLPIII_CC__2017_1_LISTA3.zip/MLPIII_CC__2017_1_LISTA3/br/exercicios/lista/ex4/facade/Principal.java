package br.exercicios.lista.ex3.fachada;

import java.util.Properties;
import java.io.FileInputStream;
import java.io.IOException;

public class Principal {
	public static void main(String args[]) {
        Properties file = new Properties();

        try {
            file.load(new FileInputStream("br/unipe/cc/mpl3/questao4/data/database.properties"));

            System.out.print("\n       URL: " + file.getProperty("conexao.url") +
                             "\n  Database: " + file.getProperty("conexao.database") +
                             "\n   Usuario: " + file.getProperty("conexao.usuario") +
                             "\n     Senha: " + file.getProperty("conexao.senha") +
                             "\n     Porta: " + file.getProperty("conexao.porta") + "\n\n");
        } catch (IOException e) {
            System.out.println("Erro durante a leitura do arquivo");
        }
    }
}
