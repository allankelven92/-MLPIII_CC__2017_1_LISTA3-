package br.exercicios.lista.ex3.fachada;

import java.util.LinkedList;
import java.util.TreeSet;
import java.util.ArrayList;
import br.exercicios.lista.ex3.modelo.Benchmark;

public class Principal {
    public static void main(String[] args) {

        Benchmark linkedList = new Benchmark(new LinkedList<>(), 10000);
        Benchmark treeSet = new Benchmark(new TreeSet<>(), 10000);
        Benchmark arrayList = new Benchmark(new ArrayList<>(), 10000);

        linkedList.teste();
        treeSet.teste();
        arrayList.teste();

        System.out.println("       Tempo  inserção     busca" +
                         "\n  LinkedList  " + linkedList +
                         "\n     TreeSet  " + treeSet +
                         "\n   ArrayList  " + arrayList);
    }
}
