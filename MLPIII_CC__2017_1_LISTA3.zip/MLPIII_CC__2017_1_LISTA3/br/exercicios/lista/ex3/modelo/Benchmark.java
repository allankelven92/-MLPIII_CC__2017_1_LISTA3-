package br.exercicios.lista.ex3.modelo;

import java.util.Collection;

public class Benchmark {
    private Collection<Integer> colletion;
    private long tempoInsercao;
    private long tempoBusca;
    private int quantidadeIntens;

	public Benchmark(Collection<Integer> colletion, int quantidadeIntens) {
		this.colletion = colletion;
        this.quantidadeIntens = quantidadeIntens;
	}

    public void teste() {
        long temp;

        this.tempoInsercao = System.currentTimeMillis();
        for(int i = 0; i < this.quantidadeIntens; i++) {
            colletion.add(i);
        }
        temp = System.currentTimeMillis();
        this.tempoInsercao = temp - this.tempoInsercao;

        this.tempoBusca = System.currentTimeMillis();
        for(int i = 0; i < this.quantidadeIntens; i++) {
            colletion.contains(i);
        }
        temp = System.currentTimeMillis();
        this.tempoBusca = temp - this.tempoBusca;
    }

    public String toString() {
        return String.format("%5d ms  %5d ms", this.tempoInsercao , this.tempoBusca);
    }
}
