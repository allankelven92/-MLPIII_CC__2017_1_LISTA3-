package br.exercicios.lista.ex2.fachada;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import br.exercicios.lista.ex2.modelo.Programador;
import br.exercicios.lista.ex2.modelo.Estado;

public class Principal {
    public static void main(String[] args) {

        List<Programador> listaProgramadores = new ArrayList<Programador>();

        listaProgramadores.add(new Programador("Maria", "566-321-894-65", 1963.53, "01/01/1985", Estado.INATIVO));
        listaProgramadores.add(new Programador("João", "123.456.789-12", 1500.00, "01/01/1990", Estado.ATIVO));
        listaProgramadores.add(new Programador("Pedro", "563-354-133-78", 3500.00, "01/01/1960", Estado.ATIVO));
        listaProgramadores.add(new Programador("Arthur", "846-231-312-79", 1263.00, "01/01/1986", Estado.INATIVO));


        Collections.sort(listaProgramadores);
        System.out.println("Lista ordenada crescente:");
        for (Programador programador : listaProgramadores) {
            System.out.println("  " + programador);
        }

        Collections.reverse(listaProgramadores);
        System.out.println("\nLista ordenada decrescente:");
        for (Programador programador : listaProgramadores) {
            System.out.println("  " + programador);
        }
    }
}
