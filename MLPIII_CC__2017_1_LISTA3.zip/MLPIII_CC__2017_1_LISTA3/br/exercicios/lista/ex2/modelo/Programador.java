package br.exercicios.lista.ex2.modelo;

import java.lang.Comparable;
import br.exercicios.lista.ex2.modelo.Estado;

public class Programador implements Comparable<Programador> {
    private String nome;
    private String cpf;
    private Double salario;
    private String data_nascimento;
    private Estado situacao_cadastral;

	public Programador(String nome, String cpf, double salario, String data_nascimento, Estado situacao_cadastral) {
		this.nome = nome;
		this.cpf = cpf;
		this.salario = salario;
		this.data_nascimento = data_nascimento;
		this.situacao_cadastral = situacao_cadastral;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public String getData_nascimento() {
		return data_nascimento;
	}

	public void setData_nascimento(String data_nascimento) {
		this.data_nascimento = data_nascimento;
	}

	public Estado getSituacao_cadastral() {
		return situacao_cadastral;
	}

	public void setSituacao_cadastral(Estado situacao_cadastral) {
		this.situacao_cadastral = situacao_cadastral;
	}

    public int compareTo(Programador programador) {
        return (this.salario).compareTo(programador.salario);
    }

    public String toString() {
        return "[Programador] " + this.nome + " " + this.cpf + " " + this.salario + " " + this.data_nascimento + " " + this.situacao_cadastral;
    }
}
