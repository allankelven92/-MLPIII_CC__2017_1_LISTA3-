package br.exercicios.lista.ex2.modelo;

public enum Estado {
    ATIVO,
    INATIVO;
}
